package lista9;

public class Fatorial {
    private int numero;

    public Fatorial(int numero) {
        this.numero = numero;
    }

    public void mostrarFatores() {
        System.out.print("Fatores de " + numero + ": ");
        for (int i = 1; i <= numero; i++) {
            if (numero % i == 0) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }
}
