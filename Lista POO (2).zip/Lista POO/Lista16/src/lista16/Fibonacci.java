package lista16;

public class Fibonacci {
    private int termos;

    public Fibonacci(int termos) {
        this.termos = termos;
    }

    public void exibirSequencia() {
        int a = 0, b = 1, c;
        for (int i = 1; i <= termos; i++) {
            System.out.print(a + " ");
            c = a + b;
            a = b;
            b = c;
        }
        System.out.println();
    }
}
