package lista19;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o primeiro termo: ");
        double primeiro = sc.nextDouble();

        System.out.print("Digite a razão: ");
        double razao = sc.nextDouble();

        System.out.print("Digite a quantidade de termos: ");
        int termos = sc.nextInt();

        PG pg = new PG(primeiro, razao, termos);
        System.out.println("Soma dos elementos da PG: " + pg.calcularSoma());

        sc.close();
    }
    
}
