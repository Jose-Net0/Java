package lista15;

public class MDC {
    private int num1;
    private int num2;

    public MDC(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    public int calcular() {
        int a = num1;
        int b = num2;
        while (b != 0) {
            int resto = a % b;
            a = b;
            b = resto;
        }
        return a;
    }
}
