package lista.pkg8;

public class Soma {
    
    private int somaatual, positivo, negativo;
   

    public Soma() {
        this.somaatual = 0;
        this.positivo = 0;
        this.negativo = 0;
    }

    public void processarNumero(int numero) {
        somaatual += numero;
        
        if (somaatual >= 0) {
            positivo++;
        } else {
            negativo++;
        }
    }

    public int getPositivo() {
        return positivo;
    }

    public int getNegativos() {
        return negativo;
    }
}
