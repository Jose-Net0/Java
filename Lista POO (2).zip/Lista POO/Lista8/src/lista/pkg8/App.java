package lista.pkg8;

import java.util.Scanner;

public class App {
    
    public static int leNumero() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite um número inteiro (0 para finalizar): ");
        return scanner.nextInt();
    }
    
    public static void main(String[] args) {
        
        Soma contador = new Soma();
        int numero;
        
        do {
            numero = leNumero();
            if (numero != 0) {
                contador.processarNumero(numero);
            }
        } while (numero != 0);

        System.out.println("Total de somas positivas (incluindo zero) = " + contador.getPositivo());
        System.out.println("Total de somas negativas = " + contador.getNegativos());
    }
}
    

