package lista10;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
        char resp;

        do {
            System.out.print("Digite o sexo (M/F): ");
            String sexo = scanner.next();

            System.out.print("Digite a altura (em metros): ");
            double altura = scanner.nextDouble();

            System.out.print("Digite o peso (em Kg): ");
            double peso = scanner.nextDouble();

            Pessoa pessoa = new Pessoa(sexo, altura, peso);

            System.out.println("Peso ideal: " + pessoa.calcularPesoIdeal());
            pessoa.verificarPeso();

            System.out.print("Deseja calcular novamente? (s/S para sim): ");
            resp = scanner.next().charAt(0);

        } while (resp == 's' || resp == 'S');

        System.out.println("Programa encerrado.");
    }
    
}
