package lista13;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite um número natural: ");
        int num = sc.nextInt();

        NumeroPrimo n = new NumeroPrimo(num);

        if (n.ehPrimo()) {
            System.out.println(num + " é um número primo.");
        } else {
            System.out.println(num + " não é um número primo.");
        }

        sc.close();
    }
}
