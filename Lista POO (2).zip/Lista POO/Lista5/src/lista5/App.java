package lista5;

import java.util.Scanner;

public class App {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite o peso:");
        double peso = sc.nextDouble();
        
        System.out.println("Digite a altura:");
        double altura = sc.nextDouble();
        
        IMC p = new IMC(peso, altura);
        
        System.out.printf("IMC: %.2f\n", p.Calculo());
        System.out.println("Situacao: " + p.Situacao());
    }
    
}
