package lista3;

import java.util.Scanner;

public class App {
    
    public static double le(int x){
        Scanner num = new Scanner(System.in);
        
        if(x==1){
            System.out.println("Digite o coeficiente a, que deve ser diferente de 0: ");
            return num.nextDouble();
        }else if(x==2){
            System.out.println("Digite o coeficiente b: ");
            return num.nextDouble();
        }else{
            System.out.println("Digite o coeficiente c: ");
            return num.nextDouble();
        }     
    }
    
     public static void main(String[] args){
        double a, b, c, d, x1, x2;

        a = le(1);
        
        while(a == 0){
            System.out.println("O coeficiente 'a' não pode ser 0. Digite novamente:");
            a = le(1);
        }

        b = le(2);
        c = le(3);

        Equa equa = new Equa(a, b, c);

        d = equa.delta();

        if(d < 0){
            System.out.println("Não existem raízes reais.");
        } else {
            x1 = equa.calculoX1(d);
            x2 = equa.calculoX2(d);

            System.out.println("O valor de x1 = " + x1);
            System.out.println("O valor de x2 = " + x2);
        }
    }
}