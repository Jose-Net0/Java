package lista11;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ParImpar pi = new ParImpar();
        PositivoNegativo pn = new PositivoNegativo();
        int num;

        do {
            System.out.print("Digite um numero (0 para sair): ");
            num = sc.nextInt();
            if (num != 0) {
                pi.processar(num);
                pn.processar(num);
            }
        } while (num != 0);

        System.out.println("\n    Resultado Par/Impar    \n");
        pi.exibir();

        System.out.println("\n    Resultado Positivo/Negativo   \n ");
        pn.exibir();

        sc.close();
    }
}
    
