package lista2;

import java.util.Scanner;

public class App {
    
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       
        System.out.print("Digite seu sexo (M/F): ");
        String sexo = sc.nextLine();

        System.out.print("Digite sua altura (em metros): ");
        double h = sc.nextDouble();
        
        Peso p = new Peso(h, sexo);
        
        p.PesoIdeal();
        System.out.println(p.exibe());
       
    }
    
}
