package lista14;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        int n1 = sc.nextInt();

        System.out.print("Digite o segundo número: ");
        int n2 = sc.nextInt();

        if (n1 <= 0 || n2 <= 0) {
            System.out.println("Os números devem ser maiores que zero!");
        } else {
            MMC mmc = new MMC(n1, n2);
            System.out.println("O MMC de " + n1 + " e " + n2 + " é " + mmc.calcular());
        }

        sc.close();
    } 
}
