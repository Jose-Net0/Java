package lista7;

import java.util.Scanner;

public class App {
    
    public static double leLado(int numero) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o valor do lado " + numero + ": ");
        return scanner.nextDouble();
    }
    
    public static void main(String[] args) {
        
        double l1 = leLado(1);
        double l2 = leLado(2);
        double l3 = leLado(3);

        Triangulo t = new Triangulo(l1, l2, l3);
        
        t.podeFormar();
        System.out.println("Esse  " + t.exibe());
    }
}
    

