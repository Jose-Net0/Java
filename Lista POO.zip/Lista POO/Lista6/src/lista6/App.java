package lista6;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite o primeiro número:");
        int a = sc.nextInt();
        
        System.out.println("Digite o segundo número:");
        int b = sc.nextInt();
        
        Media m = new Media(a, b);
        
        System.out.println("Média: " + m.Calculo());
    }
    
}
