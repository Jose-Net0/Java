package lista6;

class Media {
    
    private int a, b;
    
    public Media(int a, int b){
        this.a = a;
        this.b = b;
    }
    
    public double Calculo(){
        return (a + b) / 2.0;
    }
}
