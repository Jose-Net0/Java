package lista13;

public class NumeroPrimo {
    private int numero;

    public NumeroPrimo(int numero) {
        this.numero = numero;
    }

    public boolean ehPrimo() {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= numero / 2; i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
}
