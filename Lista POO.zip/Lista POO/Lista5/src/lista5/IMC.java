
package lista5;

public class IMC {
     private double peso, altura;
    
    public IMC(double peso, double altura){
        this.peso = peso;
        this.altura = altura;
    }
    
    public double Calculo(){
        return peso / (altura * altura);
    }
    
    public String Situacao(){
        double imc = Calculo();
        if(imc < 18.5) return "Abaixo do peso";
        else if(imc <= 25) return "Peso normal";
        else if(imc <= 30) return "Acima do peso";
        else return "Obeso";
    }
}
