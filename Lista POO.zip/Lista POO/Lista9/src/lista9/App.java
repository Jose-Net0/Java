/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista9;

import java.util.Scanner;

public class App {

     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char resp;

        do {
            System.out.print("Digite um número natural: ");
            int numero = scanner.nextInt();

            Fatorial fatores = new Fatorial(numero);
            fatores.mostrarFatores();

            System.out.print("Deseja digitar outro número? (s/S para sim): ");
            resp = scanner.next().charAt(0);

        } while (resp == 's' || resp == 'S');

        System.out.println("Programa encerrado.");
    }
}
    

