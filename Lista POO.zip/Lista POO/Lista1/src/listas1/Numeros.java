package listas1;

public class Numeros {
    private int x, y, z, soma, maior;
    
    public Numeros(int x, int y, int z){
        this.x = x;
        this.y = y;
        this.z = z;
        this.soma = soma;
        this.maior = maior;
    }
    
    public int maior(){
        
        if(x > y && x > z){
            maior = x;
            soma = y + z;
            
        }else if(y > x && y > z){
            maior = y;;
            soma = x + z;
            
        }else{
            maior = z;
            soma = x + y;
        }
        
        return soma;
    }
    
    public String exibe() {
        
        return "O maior numero foi: "+maior+"\nValor da soma dos dois menores: "+soma;
    }
}
