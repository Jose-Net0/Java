package listas1;

import java.util.Scanner;

public class App {
    
    public static int leCoordenada(int i) {
        Scanner sc = new Scanner(System.in);
        switch (i) {
            case 1:System.out.print("Digite o valor de x: ");break;
            case 2:System.out.print("Digite o valor de y: ");break;
            default:System.out.print("Digite o valor de z:");break;
        }
        return sc.nextInt();
    }
    
public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int x = leCoordenada(1);
        int y = leCoordenada(2);
        int z = leCoordenada(3);
        
        Numeros num;
        num = new Numeros(x,y,z);
        
        num.maior();
        System.out.println(num.exibe());
        
    }
    
}
