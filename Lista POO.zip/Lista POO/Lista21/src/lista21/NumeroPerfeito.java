package lista21;

public class NumeroPerfeito {
    private int numero;

    public NumeroPerfeito(int numero) {
        this.numero = numero;
    }

    public boolean ehPerfeito() {
        int soma = 0;
        for (int i = 1; i < numero; i++) {
            if (numero % i == 0) {
                soma += i;
            }
        }
        return soma == numero;
    }

}
