package lista21;

import java.util.Scanner;

public class Lista21 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite um número natural: ");
        int n = sc.nextInt();

        NumeroPerfeito np = new NumeroPerfeito(n);

        if (np.ehPerfeito()) {
            System.out.println(n + " e um numero perfeito.");
        } else {
            System.out.println(n + " nao e um numero perfeito.");
        }

        sc.close();
    }
    
}
