package lista7;

public class Triangulo {
    private double lado1;
    private double lado2;
    private double lado3;

    public Triangulo(double l1, double l2, double l3) {
        this.lado1 = l1;
        this.lado2 = l2;
        this.lado3 = l3;
    }

    public boolean podeFormar() {
        boolean cond1 = (lado1 + lado2 > lado3);
        boolean cond2 = (lado1 + lado3 > lado2);
        boolean cond3 = (lado2 + lado3 > lado1);
        
        return cond1 && cond2 && cond3;
    }

    public String exibe() {
        if (!podeFormar()) {
            return "nao forma um triangulo.";
        } else if (lado1 == lado2 && lado2 == lado3) {
            return "forma triangulo equilatero";
        } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
            return "forma triangulo isosceles";
        } else {
            return "forma triangulo escaleno";
        }
    }
}
