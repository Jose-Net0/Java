package lista2;

public class Peso {
    private double h, valor;
    private String sexo;
    
    public Peso(double h, String sexo){
        this.h = h;
        this.sexo = sexo;
                
    }
    
    public double PesoIdeal(){
         if (sexo.equals("M") || sexo.equals("m")) {
            valor = (72.7 * h) - 58;
            return valor;
            
        } else if (sexo.equals("F") || sexo.equals("f")) {
            valor = (62.1 * h) - 44.7;
            return valor;
        } else {
            return valor;
        }
    }
    
    public String exibe() {
        return String.format("Peso ideal: %.2f kg", valor);
    }
}
