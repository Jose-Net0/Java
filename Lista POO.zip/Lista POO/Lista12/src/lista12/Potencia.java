package lista12;

public class Potencia {
    private int base;
    private int expoente;

    public Potencia(int base, int expoente) {
        this.base = base;
        this.expoente = expoente;
    }

    public int calcular() {
        int resultado = 1;
        for (int i = 0; i < expoente; i++) {
            resultado *= base;
        }
        return resultado;
    }
}
