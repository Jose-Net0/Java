/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista10;

/**
 *
 * @author netog
 */
public class Pessoa {

    private String sexo;
    private double altura;
    private double peso;

    public Pessoa(String sexo, double altura, double peso) {
        this.sexo = sexo;
        this.altura = altura;
        this.peso = peso;
    }

    public double calcularPesoIdeal() {
        if (sexo.equalsIgnoreCase("f")) {
            return (62.1 * altura) - 48.7;
        } else if (sexo.equalsIgnoreCase("m")) {
            return (72.7 * altura) - 62.0;
        } else {
            return 0; // Caso o sexo seja inválido
        }
    }

    public void verificarPeso() {
        double pesoIdeal = calcularPesoIdeal();
        double diferenca = Math.abs(peso - pesoIdeal);

        if (peso == pesoIdeal) {
            System.out.println("Peso ideal");
        } else if (diferenca > 6) {
            System.out.println("Alerta de diferença de peso maior que 6 Kg");
        } else {
            System.out.println("Esta dentro da margem de peso");
        }
    }
}


