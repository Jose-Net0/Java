package lista19;

public class PG {
   private double primeiro;
    private double razao;
    private int termos;

    public PG(double primeiro, double razao, int termos) {
        this.primeiro = primeiro;
        this.razao = razao;
        this.termos = termos;
    }

    public double calcularSoma() {
        double soma = 0;
        double atual = primeiro;
        for (int i = 1; i <= termos; i++) {
            soma += atual;
            atual *= razao;
        }
        return soma;
    } 
}
