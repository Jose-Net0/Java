package lista.pkg4;

import java.util.Scanner;

public class App {
    
    public static double le(int x){
        Scanner num = new Scanner(System.in);
        
        switch (x) {
            case 1:
                System.out.println("Digite o valor de m01: ");
                return num.nextDouble();
            case 2:
                System.out.println("Digite o valor de m02: ");
                return num.nextDouble();
            default:
                System.out.println("Digite o valor de m03: ");
                return num.nextDouble();     
        }
    }

    public static void main(String[] args) {
        double m01, m02, m03, m0x;
        Scanner sc = new Scanner(System.in);
        
        m01 = le(1);
        m02 = le(2);
        m03 = le(3);
        
        CustoFinal cf = new CustoFinal(m01, m02, m03);
        
        m0x = cf.Calculo();
        
        System.out.println("O valor de m0x = " + m0x);
        
        
    }
    
}
