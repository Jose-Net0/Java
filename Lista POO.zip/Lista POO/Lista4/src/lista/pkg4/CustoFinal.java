package lista.pkg4;

public class CustoFinal {
    private double m01, m02, m03;
    
    public CustoFinal(double m01, double m02, double m03){
        
       this.m01 = m01;
       this.m02 = m02;
       this.m03 = m03;
    }
    
    public double Calculo(){
        return m01 + 3 * m02 + 2 * m03;
    }
    
            
}
