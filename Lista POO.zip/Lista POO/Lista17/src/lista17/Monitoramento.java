package lista17;

public class Monitoramento {
    private double maiorAltura;
    private double menorAltura;
    private double somaPesos;
    private int contador;

    public Monitoramento() {
        this.maiorAltura = 0;
        this.menorAltura = 0;
        this.somaPesos = 0;
        this.contador = 0;
    }

    public void processarPessoa(double peso, double altura) {
        if (contador == 0) {
            maiorAltura = altura;
            menorAltura = altura;
        } else {
            if (altura > maiorAltura) maiorAltura = altura;
            if (altura < menorAltura) menorAltura = altura;
        }
        somaPesos += peso;
        contador++;
    }

    public double getMaiorAltura() {
        return maiorAltura;
    }

    public double getMenorAltura() {
        return menorAltura;
    }

    public double getMediaPeso() {
        if (contador == 0) return 0;
        return somaPesos / contador;
    }
}
