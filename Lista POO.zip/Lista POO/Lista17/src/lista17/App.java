package lista17;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Monitoramento m = new Monitoramento();

        while (true) {
            System.out.print("Digite o peso (0 para encerrar): ");
            double peso = sc.nextDouble();
            if (peso == 0) break;
            System.out.print("Digite a altura: ");
            double altura = sc.nextDouble();
            m.processarPessoa(peso, altura);
        }

        System.out.println("Maior altura: " + m.getMaiorAltura());
        System.out.println("Menor altura: " + m.getMenorAltura());
        System.out.println("Média dos pesos: " + m.getMediaPeso());

        sc.close();
    }
    
}
