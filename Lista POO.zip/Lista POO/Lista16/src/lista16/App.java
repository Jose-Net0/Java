package lista16;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Quantos termos da sequência deseja exibir? ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("Digite um número maior que zero!");
        } else {
            Fibonacci f = new Fibonacci(n);
            f.exibirSequencia();
        }

        sc.close();
    }
    
}
