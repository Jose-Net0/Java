package lista18;

public class PA {
    private int primeiro;
    private int razao;
    private int termos;

    public PA(int primeiro, int razao, int termos) {
        this.primeiro = primeiro;
        this.razao = razao;
        this.termos = termos;
    }

    public void exibir() {
        int atual = primeiro;
        for (int i = 1; i <= termos; i++) {
            System.out.print(atual + " ");
            atual += razao;
        }
        System.out.println();
    }

}
