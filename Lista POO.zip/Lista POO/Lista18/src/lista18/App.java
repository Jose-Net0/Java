package lista18;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o primeiro termo: ");
        int primeiro = sc.nextInt();

        System.out.print("Digite a razão: ");
        int razao = sc.nextInt();

        System.out.print("Digite a quantidade de termos: ");
        int termos = sc.nextInt();

        PA pa = new PA(primeiro, razao, termos);
        pa.exibir();

        sc.close();
    }
    
}
