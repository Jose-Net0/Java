package lista3;

public class Equa {
    
      public double a, b, c;
    
    public Equa(double x,double y,double z){
        a = x;
        b = y;
        c = z;
    }
    
    public double delta(){
        return Math.pow(b,2)-4*a*c;
    }
    
    public double calculoX1(double d){
        return (-b+Math.sqrt(d))/(2*a);
    }
    
    public double calculoX2(double d){
        return (-b-Math.sqrt(d))/(2*a);
    }
}

