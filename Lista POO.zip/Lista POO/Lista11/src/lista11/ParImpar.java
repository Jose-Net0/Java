package lista11;

public class ParImpar {
    private int num;
    private int pares = 0, impares = 0, somaPares = 0, somaImpares = 0;

    public void processar(int num) {
        this.num = num;
        if (num % 2 == 0) {
            pares++;
            somaPares += num;
        } else {
            impares++;
            somaImpares += num;
        }
    }

    public void exibir() {
        System.out.println("Quantidade de pares: " + pares);
        System.out.println("Soma dos pares: " + somaPares);
        System.out.println("Quantidade de impares: " + impares);
        System.out.println("Soma dos impares: " + somaImpares);
    }
}
