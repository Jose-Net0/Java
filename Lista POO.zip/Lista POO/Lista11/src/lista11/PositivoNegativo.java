package lista11;

public class PositivoNegativo {
    private int num;
    private int positivos = 0, negativos = 0, somaPositivos = 0, somaNegativos = 0;

    public void processar(int num) {
        this.num = num;
        if (num > 0) {
            positivos++;
            somaPositivos += num;
        } else if (num < 0) {
            negativos++;
            somaNegativos += num;
        }
    }

    public void exibir() {
        System.out.println("Quantidade de positivos: " + positivos);
        System.out.println("Soma dos positivos: " + somaPositivos);
        System.out.println("Quantidade de negativos: " + negativos);
        System.out.println("Soma dos negativos: " + somaNegativos);
    }
}
