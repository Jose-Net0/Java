package lista20;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o número da tabuada: ");
        int n = sc.nextInt();

        Tabuada t = new Tabuada(n);
        t.exibir();

        sc.close();
    }
    
}
